## This project is supporting jdk/jre 8 and above version

## To run this project

# In Extracted zip file
# open command prompt in same directory

## run below commands
# mvn clean install
# go to target folder >> cd target
# java -jar coding-challenge-lathusha-0.0.1-SNAPSHOT.jar

# this jar will enable interactive mode
# Enter Upper Right Coordinates : type 5<space>5 and then enter
# Enter Rover position : type 1<space>2<space>N and then enter
# Enter instructions for rover : LMLMLMLMM
# Do you want to send another instruction to the rover? Y/N : type "Y" for giving another instruction and "N" for termination.

