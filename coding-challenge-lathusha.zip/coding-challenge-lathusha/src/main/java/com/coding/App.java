package com.coding;


import com.coding.model.Grid;
import com.coding.model.Position;
import com.coding.service.Action;
import com.coding.util.Direction;
import com.coding.util.State;
import java.util.Scanner;
import java.util.logging.Logger;

public class App 
{
    static Logger logger = Logger.getLogger(App.class.getName());
    

    public static void main( String[] args )
    {        

       
        try {
            //scan inputs for getting upper-right cordinate
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter Upper Right Coordinates");
            String[] upperRightCoord = sc.nextLine().split(" ");

            //make a grid by setting lower-Left coordinate and upper-right cordinate
            Grid grid = new Grid(new Position(0, 0),
                    new Position(Integer.parseInt(upperRightCoord[0]), Integer.parseInt(upperRightCoord[1])));

            //String instructions = "LMLMLMLMM";
            //String instructions = "MMRMMRMRRM";

            String instr = "N";
            try {
                do {
                    collectInput(sc, grid);
                    System.out.println("Do you want to send another instruction to the rover? Y/N :");
                    instr = sc.nextLine();
                } while (instr.equals("Y"));
            } catch (Exception exception) {
                System.out.println(exception.getMessage());
            }
        } catch (NumberFormatException | NullPointerException exception) {
            System.out.println(exception.getMessage());
        } catch (Exception exception) {
            System.out.println(exception.getMessage());
        }
        
    }

     private static void collectInput(Scanner sc, Grid grid) {
        //scan and set current position of rover
        System.out.println("Enter Rover position");
        String[] roverPosition = sc.nextLine().split(" ");
        State currentState = new State(new Position(Integer.parseInt(roverPosition[0]),
                Integer.parseInt(roverPosition[1])), Direction.valueOf(roverPosition[2]));

        //scan and pass instructions to take action
        System.out.println("Enter instructions for rover");
        String instructions = sc.nextLine();
        sendInstructions(instructions.toCharArray(), currentState, grid);
    }


    private static void sendInstructions(char[] instructionsCharArray, State currentState, Grid grid) {
       Action action = new Action();
        try {
            for (char instruction : instructionsCharArray) {
                if (instruction != ' ') {
                    //logger.info("Instruction = "+instruction);
                    currentState = action.act(instruction, currentState, grid);
                }
            }
            logger.info("Current state of rover = " + currentState);
        } catch (Exception exception) {
            System.out.println(exception.getMessage());
        }

    }
}
