package com.coding.service;

import com.coding.model.Grid;
import com.coding.model.Position;
import com.coding.util.Constants;
import com.coding.util.Direction;
import com.coding.util.State;

import java.util.logging.Logger;

public class Action {
    static Logger logger = Logger.getLogger(Action.class.getName());

    public State act(char instruction, State currentState, Grid grid) throws Exception {
        //L,R,M
        switch (instruction) {
            case 'L':
                currentState = rotateToLeft(currentState);
                break;
            case 'R':
                currentState = rotateToRight(currentState);
                break;
            case 'M':
                currentState = moveAhead(currentState, grid);
                break;
            default:
                currentState = new State(new Position(-1, -1), Direction.I);
                break;

        }
        return currentState;
    }

    public State moveAhead(State currentState, Grid grid) throws Exception {
        // logger.info("In moving state with grid ="+grid+" :: "+ currentState);
        int xCoord, yCoord = 0;
        Position position = currentState.getPosition();
        if (currentState.getDirection() == Direction.E) {
            xCoord = position.getX();
            currentState = resetCoordinate(currentState, grid, ++xCoord, Constants.X);
        } else if (currentState.getDirection() == Direction.W) {
            xCoord = position.getX();
            currentState = resetCoordinate(currentState, grid, --xCoord, Constants.X);
        } else if (currentState.getDirection() == Direction.N) {
            yCoord = position.getY();
            currentState = resetCoordinate(currentState, grid, ++yCoord, Constants.Y);
        } else if (currentState.getDirection() == Direction.S) {
            yCoord = position.getY();
            currentState = resetCoordinate(currentState, grid, --yCoord, Constants.Y);
        }

        return currentState;
    }

    public State resetCoordinate(State currentState, Grid grid, int value, String coord) throws Exception {

        if (grid.getUpperRightCoord().getX() > 0 && grid.getUpperRightCoord().getY() > 0
                && grid.getLowerLeftCoord().getX() >= 0 && grid.getLowerLeftCoord().getY() >= 0) {
            if (coord.equals(Constants.X)
                    && (currentState.getPosition().getX() >= grid.getLowerLeftCoord().getX()
                    && currentState.getPosition().getX() <= grid.getUpperRightCoord().getX()
                    && value <= grid.getUpperRightCoord().getX())) {
                currentState.getPosition().setX(value);
            } else if (coord.equals(Constants.Y)
                    && (currentState.getPosition().getY() >= grid.getLowerLeftCoord().getY()
                    && currentState.getPosition().getY() <= grid.getUpperRightCoord().getY()
                    && value <= grid.getUpperRightCoord().getY())) {
                currentState.getPosition().setY(value);
            } else {
                //logger.info("Access Denied!");
                throw new Exception("Rover trying to move out of grid");
            }
        } else {
            throw new Exception("Rover trying to move out of grid");
        }
        return currentState;
    }

    public State rotateToRight(State currentState) {
        if (currentState.getDirection() == Direction.E) {
            currentState.setDirection(Direction.S);
        } else if (currentState.getDirection() == Direction.N) {
            currentState.setDirection(Direction.E);
        } else if (currentState.getDirection() == Direction.W) {
            currentState.setDirection(Direction.N);
        } else if (currentState.getDirection() == Direction.S) {
            currentState.setDirection(Direction.W);
        }
        return currentState;
    }

    public State rotateToLeft(State currentState) {
        //no change in coordinated
        //find the direction and make change to 90 deg
        if (currentState.getDirection() == Direction.E) {
            currentState.setDirection(Direction.N);
        } else if (currentState.getDirection() == Direction.N) {
            currentState.setDirection(Direction.W);
        } else if (currentState.getDirection() == Direction.W) {
            currentState.setDirection(Direction.S);
        } else if (currentState.getDirection() == Direction.S) {
            currentState.setDirection(Direction.E);
        }
        return currentState;
    }

}
