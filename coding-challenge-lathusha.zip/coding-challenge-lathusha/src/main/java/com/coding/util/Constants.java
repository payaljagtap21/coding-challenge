package com.coding.util;

public class Constants {
    public static final String X = "X";
    public static final String Y = "Y";
}
