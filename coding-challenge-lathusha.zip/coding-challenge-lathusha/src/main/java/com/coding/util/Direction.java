package com.coding.util;

public enum Direction {
    E,W,N,S,I
}
