package com.coding.util;

import com.coding.model.Position;

public class State {

    private Position position;
    private Direction direction;

    public State() {
    }

    public State(Position position, Direction direction) {
        this.position = position;
        this.direction = direction;
    }

    public Position getPosition() {
        return position;
    }

    public void setPosition(Position position) {
        this.position = position;
    }

    public Direction getDirection() {
        return direction;
    }

    public void setDirection(Direction direction) {
        this.direction = direction;
    }

    @Override
    public String toString() {
        return "State{" +
                "position=" + position +
                ", direction=" + direction +
                '}';
    }
}
