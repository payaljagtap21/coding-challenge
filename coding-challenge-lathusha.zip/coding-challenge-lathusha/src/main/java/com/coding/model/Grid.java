package com.coding.model;

public class Grid {
    private Position lowerLeftCoord;
    private Position upperRightCoord;
    public Grid(Position lowerLeftCoord, Position upperRightCoord) {
        this.lowerLeftCoord = lowerLeftCoord;
        this.upperRightCoord = upperRightCoord;
    }
    public Position getLowerLeftCoord() {
        return lowerLeftCoord;
    }

    public void setLowerLeftCoord(Position lowerLeftCoord) {
        this.lowerLeftCoord = lowerLeftCoord;
    }

    public Position getUpperRightCoord() {
        return upperRightCoord;
    }

    public void setUpperRightCoord(Position upperRightCoord) {
        this.upperRightCoord = upperRightCoord;
    }

    @Override
    public String toString() {
        return "Grid{" +
                "lowerLeftCoord=" + lowerLeftCoord +
                ", upperRightCoord=" + upperRightCoord +
                '}';
    }
}
