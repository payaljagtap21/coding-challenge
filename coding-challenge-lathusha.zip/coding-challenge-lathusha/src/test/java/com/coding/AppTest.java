package com.coding;

import com.coding.service.Action;  
import org.junit.Test; 
import com.coding.model.Grid;
import com.coding.model.Position;
import com.coding.service.Action;
import com.coding.util.Direction;
import com.coding.util.State;
import org.junit.jupiter.api.Assertions;

public class AppTest 
{
    Action action = new Action();

    @Test
    public void rotateLeftTest() {
        // given
        State givenState = new State();
        Position dummyPosition = new Position(0, 0);
        givenState.setPosition(dummyPosition);
        givenState.setDirection(Direction.E);

        //when
        State newState = action.rotateToLeft(givenState);

        //then
        Assertions.assertEquals(newState.getDirection(), Direction.N);
    }

    //right rotation working properly(given current position; when instruction "R" then verify expected answer)
    @Test
    public void rotateRightTest() {
        // given
        State givenState = new State();
        Position dummyPosition = new Position(0, 0);
        givenState.setPosition(dummyPosition);
        givenState.setDirection(Direction.E);

        // when
        State newState = action.rotateToRight(givenState);

        // then
        Assertions.assertEquals(newState.getDirection(), Direction.S);
    }

    //move working properly(given current position; when instruction "M" then verify expected answer)
    @Test
    public void moveNextStep() {
        //given
        Grid grid = new Grid(new Position(0, 0), new Position(5, 5));
        Position currentPosition = new Position(1, 2);
        State currentState = new State(currentPosition, Direction.N);

        //when
        State resultState = null;
        try {
            resultState = action.moveAhead(currentState, grid);
        } catch (Exception e) {
            System.out.println("Error = " + e);
        }
        //then
        Position expectedPosition = new Position(1, 3);
        Assertions.assertEquals(resultState.getPosition().getX(), expectedPosition.getX());
        Assertions.assertEquals(resultState.getPosition().getY(), expectedPosition.getY());
    }


    //rover trying to go out of grid
    @Test
    public void checkMovementLimit() {
        //given
        Grid grid = new Grid(new Position(0, 0), new Position(5, 5));
        Position currentPosition = new Position(4, 4);
        State currentState = new State(currentPosition, Direction.N);
        String instructions = "MRMM";

        //when
        char[] arr = instructions.toCharArray();
        Exception exception = Assertions.assertThrows(Exception.class, () -> {
            State resultState = null;
            for (char instruction : arr) {
                if (instruction != ' ') {
                    resultState = action.act(instruction, currentState, grid);
                }
            }
        });

        //then
        Assertions.assertEquals("Rover trying to move out of grid", exception.getMessage());
    }

    //starting position of rover is out of bound
    @Test
    public void checkStartPosition() {
        //given
        Grid grid = new Grid(new Position(-1, -1), new Position(5, 5));
        Position currentPosition = new Position(1, 2);
        State currentState = new State(currentPosition, Direction.N);
        char instruction1 = 'M';
        //when
        Exception exception = Assertions.assertThrows(Exception.class, () -> {
            State resultState = null;
            resultState = action.act(instruction1, currentState, grid);
        });

        //then
        Assertions.assertEquals("Rover trying to move out of grid", exception.getMessage());
    }

    //right most point of grid in input is not valid( negative numbers)
    @Test
    public void validateUpperRightCoordinate() {
        //given
        Grid grid = new Grid(new Position(0, 0), new Position(-5, -5));
        Position currentPosition = new Position(1, 2);
        State currentState = new State(currentPosition, Direction.N);
        char instruction1 = 'M';
        //when
        Exception exception = Assertions.assertThrows(Exception.class, () -> {
            State resultState = null;
            resultState = action.act(instruction1, currentState, grid);
        });

        //then
        Assertions.assertEquals("Rover trying to move out of grid", exception.getMessage());
    }

    //invalid instruction (unknown instruction)
    @Test
    public void validateInstruction() {
        //given
        Grid grid = new Grid(new Position(0, 0), new Position(5, 5));
        Position currentPosition = new Position(1, 2);
        State currentState = new State(currentPosition, Direction.N);
        char instruction = 'T';
        //when
        try {
            currentState = action.act(instruction, currentState, grid);
        } catch (Exception e) {
            System.out.println("Error=" + e.getMessage());
        }
        //then
        Assertions.assertEquals(currentState.getDirection(), Direction.I);
        Assertions.assertEquals(currentState.getPosition().getX(), -1);
        Assertions.assertEquals(currentState.getPosition().getY(), -1);
    }
}
